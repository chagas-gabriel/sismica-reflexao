#! /bin/sh


#plot synthetic data

# escala horizontal calculada pela palavra-chave d2 no cabeçalho
box="wbox=900 hbox=600 perc=98 "

data=$1
if [ "z$1" = "z" ] 
then 
   echo -n "Entre com o nome do arquivo de dados"
   echo "  "
   read data
fi

suximage <$data label1="Tempo (s)" label2="Coordenada do CMP (km)"  \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title=" " $box windowtitle="image  $data " &

suxwigb <$data label1="Tempo (s)" label2="Coordenada do CMP (km)"  \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="file: $data " $box xbox=400 windowtitle="wig $data " &

#label1="Time (s)" label2="Midpoint (km)"
