#! /bin/sh

# Migracao Stolt (dominio da fequencia)

box="wbox=900 hbox=550  "

cdpmin=1 tmig=0.0 verbose=0


#cdpmax=201 dxcdp=40
#cdpmax=401 dxcdp=20

data=$1
if [ "z$1" = "z" ] 
then 
   echo -n "Entre com o nome do arquivo de dados"
   echo "  "
   read data
fi

echo "entre com o intervalo entre CMPs [em metros]"
read dxcdp

cdpmax=`bc -l <<-END
scale=0
1 + (8 / ($dxcdp*.001))
END`
echo $cdpmax

echo "entre com a velocidade"
read vmig 

sustolt < $data cdpmin=$cdpmin cdpmax=$cdpmax dxcdp=$dxcdp vmig=$vmig tmig=$tmig verbose=$verbose   > $data.stolt

#2> /dev/null

suximage < $data.stolt label1="Tempo (s)" label2="Coordenada do CMP (km)" \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2=0 f2num=0.0 d2num=1.0 n2tic=4  windowtitle="Stolt migration   $data" title="vmig=$vmig"  $box &


