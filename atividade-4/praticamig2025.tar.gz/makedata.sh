#! /bin/sh

#script makedata.sh
#Liliana 09/2009
#para AGG407 e AGG323

dt=.004 ft=0.0 fx=0.0
#nx=401 dx=0.02 
#nx=201 dx=0.04 

echo " entre com a frequencia dominante da wavele"
read fpeak

echo " entre com o intervalo dx em kilometros"
read dx

nx=`bc -l <<-END
scale=0
1 + (8 / $dx)
END`

dxm=`bc -l <<-END
scale=0  
$dx/.001
END`

echo $nx $dxm

nt=2001 ###################################################

data=data"$fpeak".8.dx"$dxm"

susynlv >$data dt=$dt nt=$nt fpeak=$fpeak dxm=$dx nxm=$nx \
       er=1 ob=0 kilounits=1 v00=1.5 dvdx=0 dvdz=0 smooth=1 \
ref="1:0.0,.5;1.0,.5;2.,2.0;3.0,2.0;4.0,3.0;5.0,2.0;6.0,2.0"



suximage <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2=0 f2num=0.0 d2num=1.0 n2tic=4  title="file: $data " $box windowtitle="  ximage (fpeak=$fpeak, dt=$dt dx=$dx)" &



exit
fpeak=20
data=data"$fpeak".8..dx"dxm"

susynlv >$data dt=$dt nt=$nt fpeak=20 dxm=$dx nxm=$nx \
       er=1 ob=0 kilounits=1 v00=1.5 dvdx=0 dvdz=0 smooth=1 \
ref="1:0.0,.5;1.0,.5;2.,2.0;3.0,2.0;4.0,3.0;5.0,2.0;6.0,2.0"



dt=.004 ft=0.0
nx=201 dx=0.04 fx=0.0

nt=1251 ###################################################
fpeak=10
data=data"$fpeak"

susynlv >$data dt=$dt nt=$nt fpeak=10 dxm=$dx nxm=$nx \
       er=1 ob=0 kilounits=1 v00=1.5 dvdx=0 dvdz=0 smooth=1 \
ref="1:0.0,.5;1.0,.5;2.,2.0;3.0,2.0;4.0,3.0;5.0,2.0;6.0,2.0"

fpeak=20
data=data"$fpeak"

susynlv >$data dt=$dt nt=$nt fpeak=20 dxm=$dx nxm=$nx \
       er=1 ob=0 kilounits=1 v00=1.5 dvdx=0 dvdz=0 smooth=1 \
ref="1:0.0,.5;1.0,.5;2.,2.0;3.0,2.0;4.0,3.0;5.0,2.0;6.0,2.0"


nt=2001 #####################################################
fpeak=10
data=data"$fpeak".8sec

susynlv >$data dt=$dt nt=$nt fpeak=10 dxm=$dx nxm=$nx \
       er=1 ob=0 kilounits=1 v00=1.5 dvdx=0 dvdz=0 smooth=1 \
ref="1:0.0,.5;1.0,.5;2.,2.0;3.0,2.0;4.0,3.0;5.0,2.0;6.0,2.0"

fpeak=20
data=data"$fpeak".8sec

susynlv >$data dt=$dt nt=$nt fpeak=20 dxm=$dx nxm=$nx \
       er=1 ob=0 kilounits=1 v00=1.5 dvdx=0 dvdz=0 smooth=1 \
ref="1:0.0,.5;1.0,.5;2.,2.0;3.0,2.0;4.0,3.0;5.0,2.0;6.0,2.0"


#plot synthetic data
# escala horizontal calculada pela palavra-chave d2 no cabeçalho
box="wbox=900 hbox=600  "

#frequencia de pico da wavelet = 10
data=data10.8sec

suximage <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="file: $data " $box windowtitle="  ximage (fpeak=10, Tmax=8s))" &

suxwigb <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="file: $data " $box windowtitle="  xwigb (fpeak=10, Tmax=8s))" &

exit
data=data20.8sec

suximage <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="file: $data" $box windowtitle="  ximage (fpeak=20, Tmax=8s))" &

suxwigb <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="Model Data file:$data " $box windowtitle="  xwigb (fpeak=20, Tmax=8s))" &

data=data10

suximage <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="file: $data" $box windowtitle="  ximage (fpeak=10, Tmax=5s))" &

data=data20

suximage <$data label1="Time (s)" label2="Midpoint (km)" perc=98 \
d1num=1 n1tic=1 grid1=dot grid2=dot gridcolor=yellow  \
f2num=0.0 d2num=1.0 n2tic=4  title="file: $data" $box windowtitle="  ximage (fpeak=20, Tmax=5s))"&


exit
kilounits=1            input length units are km
			=0 for m

Notes: 
Offsets are signed - may be positive or negative.  Receiver locations	
are computed by adding the signed offset to the source location.	
									
Specify either midpoint sampling or shotpoint sampling, but not both.	
If neither is specified, the default is the midpoint sampling above.	
									
More than one ref (reflector) may be specified. Do this by putting	
additional ref= entries on the commandline. When obliquity factors	
are included, then only the left side of each reflector (as the x,z	
reflector coordinates are traversed) is reflecting.  For example, if x	
coordinates increase, then the top side of a reflector is reflecting.	
Note that reflectors are encoded as quoted strings, with an optional	
reflector amplitude: preceding the x,z coordinates of each reflector.	
Default amplitude is 1.0 if amplitude: part of the string is omitted.	


